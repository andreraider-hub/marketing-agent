'use client';
import { useState, useEffect } from 'react';

type Tab = 'ads' | 'seo' | 'copy' | 'konten' | 'analisis' | 'produk';

interface Produk {
  nama: string;
  deskripsi: string;
  audiens: string;
  keunggulan: string;
}

const TABS = [
  { id: 'ads', label: '📢 Ads' },
  { id: 'seo', label: '🔍 SEO' },
  { id: 'copy', label: '✍️ Copywriting' },
  { id: 'konten', label: '💡 Ide Konten' },
  { id: 'analisis', label: '📊 Analisis' },
  { id: 'produk', label: '🗂️ Data Produk' },
];

export default function Home() {
  const [tab, setTab] = useState<Tab>('ads');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [produkList, setProdukList] = useState<Produk[]>([]);
  const [loadingProduk, setLoadingProduk] = useState(false);

  // Ads fields
  const [adsProduk, setAdsProduk] = useState('');
  const [adsAudiens, setAdsAudiens] = useState('');
  const [adsPlatform, setAdsPlatform] = useState('Instagram / Facebook');
  const [adsTujuan, setAdsTujuan] = useState('Brand awareness');
  const [adsKeunggulan, setAdsKeunggulan] = useState('');

  // SEO fields
  const [seoTopik, setSeoTopik] = useState('');
  const [seoJenis, setSeoJenis] = useState('Artikel blog');
  const [seoAudiens, setSeoAudiens] = useState('');
  const [seoTone, setSeoTone] = useState('Informatif & edukatif');
  const [seoKeywords, setSeoKeywords] = useState('');

  // Copy fields
  const [copyProduk, setCopyProduk] = useState('');
  const [copyJenis, setCopyJenis] = useState('Headline');
  const [copyEmosi, setCopyEmosi] = useState('Urgensi / FOMO');
  const [copyPanjang, setCopyPanjang] = useState('Pendek (1-2 kalimat)');
  const [copyBrief, setCopyBrief] = useState('');

  // Konten fields
  const [kontenNiche, setKontenNiche] = useState('');
  const [kontenPlatform, setKontenPlatform] = useState('Instagram');
  const [kontenJumlah, setKontenJumlah] = useState('10 ide');
  const [kontenFormat, setKontenFormat] = useState('Campuran (semua format)');
  const [kontenFokus, setKontenFokus] = useState('');

  // Analisis fields
  const [analisisJenis, setAnalisisJenis] = useState('Analisis kompetitor');
  const [analisisData, setAnalisisData] = useState('');
  const [analisisPertanyaan, setAnalisisPertanyaan] = useState('');

  // Produk form
  const [pNama, setPNama] = useState('');
  const [pDeskripsi, setPDeskripsi] = useState('');
  const [pAudiens, setPAudiens] = useState('');
  const [pKeunggulan, setPKeunggulan] = useState('');
  const [savingProduk, setSavingProduk] = useState(false);

  useEffect(() => {
    if (tab === 'produk') fetchProduk();
  }, [tab]);

  async function fetchProduk() {
    setLoadingProduk(true);
    try {
      const res = await fetch('/api/sheets');
      const data = await res.json();
      setProdukList(data.data || []);
    } catch {}
    setLoadingProduk(false);
  }

  async function saveProduk() {
    setSavingProduk(true);
    try {
      await fetch('/api/sheets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nama: pNama, deskripsi: pDeskripsi, audiens: pAudiens, keunggulan: pKeunggulan }),
      });
      setPNama(''); setPDeskripsi(''); setPAudiens(''); setPKeunggulan('');
      fetchProduk();
    } catch {}
    setSavingProduk(false);
  }

  function buildPrompt(): { prompt: string; meta: string } {
    if (tab === 'ads') {
      return {
        meta: `${adsProduk} | ${adsPlatform} | ${adsTujuan}`,
        prompt: `Kamu adalah copywriter iklan profesional. Buat 3 variasi copy iklan untuk:\n- Produk: ${adsProduk || '[tidak diisi]'}\n- Target Audiens: ${adsAudiens || '[tidak diisi]'}\n- Platform: ${adsPlatform}\n- Tujuan: ${adsTujuan}\n${adsKeunggulan ? '- Keunggulan: ' + adsKeunggulan : ''}\n\nUntuk setiap variasi berikan: Headline, Body copy, dan CTA. Gunakan bahasa Indonesia yang natural.`,
      };
    }
    if (tab === 'seo') {
      return {
        meta: `${seoTopik} | ${seoJenis} | ${seoTone}`,
        prompt: `Kamu adalah SEO specialist. Buat ${seoJenis} untuk:\n- Topik: ${seoTopik || '[tidak diisi]'}\n- Audiens: ${seoAudiens || '[tidak diisi]'}\n- Tone: ${seoTone}\n${seoKeywords ? '- Kata kunci tambahan: ' + seoKeywords : ''}\n\nBerikan: Judul SEO-friendly, Meta description (max 160 karakter), Outline H2/H3, Kata kunci LSI, Tips optimasi on-page.`,
      };
    }
    if (tab === 'copy') {
      return {
        meta: `${copyProduk} | ${copyJenis} | ${copyEmosi}`,
        prompt: `Kamu adalah copywriter profesional. Buat ${copyJenis} untuk:\n- Produk: ${copyProduk || '[tidak diisi]'}\n- Emosi: ${copyEmosi}\n- Panjang: ${copyPanjang}\n${copyBrief ? '- Brief: ' + copyBrief : ''}\n\nBuat 2 versi berbeda. Jelaskan strategi singkat di balik setiap versi.`,
      };
    }
    if (tab === 'konten') {
      return {
        meta: `${kontenNiche} | ${kontenPlatform} | ${kontenJumlah}`,
        prompt: `Kamu adalah content strategist. Buat ${kontenJumlah} ide konten untuk:\n- Niche: ${kontenNiche || '[tidak diisi]'}\n- Platform: ${kontenPlatform}\n- Format: ${kontenFormat}\n${kontenFokus ? '- Fokus: ' + kontenFokus : ''}\n\nUntuk setiap ide: judul/hook, format, deskripsi singkat, potensi engagement.`,
      };
    }
    return {
      meta: `${analisisJenis}`,
      prompt: `Kamu adalah marketing strategist. Lakukan ${analisisJenis}:\n\nData:\n${analisisData || '[tidak ada data]'}\n${analisisPertanyaan ? '\nPertanyaan: ' + analisisPertanyaan : ''}\n\nBerikan analisis terstruktur, insight kunci, rekomendasi konkret, peluang dan risiko.`,
    };
  }

  async function generate() {
    setLoading(true);
    setResult('');
    setSaved(false);
    const { prompt, meta } = buildPrompt();
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tab, prompt, meta }),
      });
      const data = await res.json();
      setResult(data.result || data.error || 'Error');
      setSaved(true);
    } catch {
      setResult('Gagal menghubungi server.');
    }
    setLoading(false);
  }

  const s: Record<string, React.CSSProperties> = {
    wrap: { maxWidth: 780, margin: '0 auto', padding: '24px 16px' },
    header: { marginBottom: 24 },
    h1: { fontSize: 26, fontWeight: 700, color: '#111' },
    sub: { fontSize: 14, color: '#666', marginTop: 4 },
    tabs: { display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 },
    tab: { padding: '8px 16px', borderRadius: 8, border: '1.5px solid #e0e0e0', cursor: 'pointer', fontSize: 14, background: '#fff', color: '#555', fontWeight: 500, transition: 'all 0.15s' },
    tabActive: { padding: '8px 16px', borderRadius: 8, border: '1.5px solid #111', cursor: 'pointer', fontSize: 14, background: '#111', color: '#fff', fontWeight: 500 },
    card: { background: '#fff', borderRadius: 12, border: '1px solid #e8e8e8', padding: 24, boxShadow: '0 1px 4px rgba(0,0,0,0.05)' },
    row: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 },
    field: { marginBottom: 16 },
    label: { display: 'block', fontSize: 13, fontWeight: 500, color: '#444', marginBottom: 6 },
    input: { width: '100%', padding: '9px 12px', border: '1.5px solid #e0e0e0', borderRadius: 8, fontSize: 14, color: '#111', background: '#fff', outline: 'none', fontFamily: 'inherit' },
    textarea: { width: '100%', padding: '9px 12px', border: '1.5px solid #e0e0e0', borderRadius: 8, fontSize: 14, color: '#111', background: '#fff', outline: 'none', fontFamily: 'inherit', resize: 'vertical', minHeight: 90 },
    select: { width: '100%', padding: '9px 12px', border: '1.5px solid #e0e0e0', borderRadius: 8, fontSize: 14, color: '#111', background: '#fff', outline: 'none', fontFamily: 'inherit' },
    btn: { width: '100%', padding: '11px', borderRadius: 8, border: 'none', background: '#111', color: '#fff', fontSize: 15, fontWeight: 600, cursor: 'pointer', marginTop: 4 },
    btnDisabled: { width: '100%', padding: '11px', borderRadius: 8, border: 'none', background: '#999', color: '#fff', fontSize: 15, fontWeight: 600, cursor: 'not-allowed', marginTop: 4 },
    result: { marginTop: 20, background: '#f8f9fa', borderRadius: 10, padding: 18, fontSize: 14, lineHeight: 1.8, whiteSpace: 'pre-wrap', color: '#222', border: '1px solid #e8e8e8' },
    savedBadge: { display: 'inline-block', marginTop: 10, background: '#e6f4ea', color: '#2d7a3a', borderRadius: 6, padding: '4px 12px', fontSize: 13, fontWeight: 500 },
    produkTable: { width: '100%', borderCollapse: 'collapse', fontSize: 13, marginTop: 16 },
    th: { padding: '8px 12px', background: '#f5f5f5', textAlign: 'left', borderBottom: '1px solid #e0e0e0', fontWeight: 600 },
    td: { padding: '8px 12px', borderBottom: '1px solid #f0f0f0', verticalAlign: 'top' },
  };

  return (
    <div style={s.wrap}>
      <div style={s.header}>
        <h1 style={s.h1}>🤖 Marketing Agent</h1>
        <p style={s.sub}>AI untuk Ads · SEO · Copywriting · Ide Konten · Analisis — tersimpan otomatis ke Google Sheets</p>
      </div>

      <div style={s.tabs}>
        {TABS.map((t) => (
          <button key={t.id} style={tab === t.id ? s.tabActive : s.tab} onClick={() => { setTab(t.id as Tab); setResult(''); setSaved(false); }}>
            {t.label}
          </button>
        ))}
      </div>

      <div style={s.card}>
        {/* ADS */}
        {tab === 'ads' && (
          <>
            <div style={s.row}>
              <div><label style={s.label}>Produk / Layanan</label><input style={s.input} value={adsProduk} onChange={e => setAdsProduk(e.target.value)} placeholder="Skincare serum vitamin C" /></div>
              <div><label style={s.label}>Target Audiens</label><input style={s.input} value={adsAudiens} onChange={e => setAdsAudiens(e.target.value)} placeholder="Wanita 25-35 tahun" /></div>
            </div>
            <div style={s.row}>
              <div><label style={s.label}>Platform</label>
                <select style={s.select} value={adsPlatform} onChange={e => setAdsPlatform(e.target.value)}>
                  {['Instagram / Facebook','Google Ads','TikTok','YouTube','LinkedIn'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
              <div><label style={s.label}>Tujuan Iklan</label>
                <select style={s.select} value={adsTujuan} onChange={e => setAdsTujuan(e.target.value)}>
                  {['Brand awareness','Penjualan langsung','Lead generation','Traffic ke website'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
            </div>
            <div style={s.field}><label style={s.label}>Keunggulan Produk (opsional)</label><textarea style={s.textarea} value={adsKeunggulan} onChange={e => setAdsKeunggulan(e.target.value)} placeholder="Mengandung 15% vitamin C, dermatologist tested..." /></div>
          </>
        )}

        {/* SEO */}
        {tab === 'seo' && (
          <>
            <div style={s.row}>
              <div><label style={s.label}>Topik / Kata Kunci Utama</label><input style={s.input} value={seoTopik} onChange={e => setSeoTopik(e.target.value)} placeholder="cara merawat kulit berminyak" /></div>
              <div><label style={s.label}>Jenis Konten</label>
                <select style={s.select} value={seoJenis} onChange={e => setSeoJenis(e.target.value)}>
                  {['Artikel blog','Landing page','Deskripsi produk','Meta description','FAQ'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
            </div>
            <div style={s.row}>
              <div><label style={s.label}>Target Audiens</label><input style={s.input} value={seoAudiens} onChange={e => setSeoAudiens(e.target.value)} placeholder="pemula, mahasiswa, ibu rumah tangga" /></div>
              <div><label style={s.label}>Tone</label>
                <select style={s.select} value={seoTone} onChange={e => setSeoTone(e.target.value)}>
                  {['Informatif & edukatif','Santai & casual','Profesional','Persuasif'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
            </div>
            <div style={s.field}><label style={s.label}>Kata Kunci Tambahan (opsional)</label><input style={s.input} value={seoKeywords} onChange={e => setSeoKeywords(e.target.value)} placeholder="skincare, kulit sehat, vitamin c" /></div>
          </>
        )}

        {/* COPY */}
        {tab === 'copy' && (
          <>
            <div style={s.row}>
              <div><label style={s.label}>Produk / Brand</label><input style={s.input} value={copyProduk} onChange={e => setCopyProduk(e.target.value)} placeholder="Kopi lokal Bandung" /></div>
              <div><label style={s.label}>Jenis Copy</label>
                <select style={s.select} value={copyJenis} onChange={e => setCopyJenis(e.target.value)}>
                  {['Headline','Email marketing','Caption media sosial','Tagline brand','Product description','CTA (Call to Action)'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
            </div>
            <div style={s.row}>
              <div><label style={s.label}>Emosi</label>
                <select style={s.select} value={copyEmosi} onChange={e => setCopyEmosi(e.target.value)}>
                  {['Urgensi / FOMO','Kepercayaan','Kesenangan','Inspirasi','Eksklusivitas'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
              <div><label style={s.label}>Panjang</label>
                <select style={s.select} value={copyPanjang} onChange={e => setCopyPanjang(e.target.value)}>
                  {['Pendek (1-2 kalimat)','Medium (1 paragraf)','Panjang (3-5 paragraf)'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
            </div>
            <div style={s.field}><label style={s.label}>Brief Tambahan (opsional)</label><textarea style={s.textarea} value={copyBrief} onChange={e => setCopyBrief(e.target.value)} placeholder="Detail, angle, atau info lain..." /></div>
          </>
        )}

        {/* KONTEN */}
        {tab === 'konten' && (
          <>
            <div style={s.row}>
              <div><label style={s.label}>Niche / Industri</label><input style={s.input} value={kontenNiche} onChange={e => setKontenNiche(e.target.value)} placeholder="fashion muslimah, kuliner, teknologi" /></div>
              <div><label style={s.label}>Platform</label>
                <select style={s.select} value={kontenPlatform} onChange={e => setKontenPlatform(e.target.value)}>
                  {['Instagram','TikTok','YouTube','LinkedIn','Twitter / X','Blog'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
            </div>
            <div style={s.row}>
              <div><label style={s.label}>Jumlah Ide</label>
                <select style={s.select} value={kontenJumlah} onChange={e => setKontenJumlah(e.target.value)}>
                  {['5 ide','10 ide','15 ide','30 ide (1 bulan)'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
              <div><label style={s.label}>Format Konten</label>
                <select style={s.select} value={kontenFormat} onChange={e => setKontenFormat(e.target.value)}>
                  {['Campuran (semua format)','Video / Reels','Carousel / Infografis','Foto produk','Story'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
            </div>
            <div style={s.field}><label style={s.label}>Fokus Konten (opsional)</label><input style={s.input} value={kontenFokus} onChange={e => setKontenFokus(e.target.value)} placeholder="meningkatkan engagement, promosi produk baru..." /></div>
          </>
        )}

        {/* ANALISIS */}
        {tab === 'analisis' && (
          <>
            <div style={s.field}><label style={s.label}>Jenis Analisis</label>
              <select style={s.select} value={analisisJenis} onChange={e => setAnalisisJenis(e.target.value)}>
                {['Analisis kompetitor','Review strategi konten','Analisis target market','Evaluasi copy / materi iklan','Strategi marketing untuk produk baru'].map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <div style={s.field}><label style={s.label}>Konteks / Data</label><textarea style={{ ...s.textarea, minHeight: 130 }} value={analisisData} onChange={e => setAnalisisData(e.target.value)} placeholder="Deskripsikan produk, brand, kompetitor, atau paste copy yang ingin dievaluasi..." /></div>
            <div style={s.field}><label style={s.label}>Pertanyaan Spesifik (opsional)</label><input style={s.input} value={analisisPertanyaan} onChange={e => setAnalisisPertanyaan(e.target.value)} placeholder="Apa kelemahan strategi ini? Bagaimana cara meningkatkan konversi?" /></div>
          </>
        )}

        {/* PRODUK DATA */}
        {tab === 'produk' && (
          <>
            <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>➕ Tambah Data Produk</h3>
            <div style={s.row}>
              <div><label style={s.label}>Nama Produk</label><input style={s.input} value={pNama} onChange={e => setPNama(e.target.value)} placeholder="Skincare Serum" /></div>
              <div><label style={s.label}>Target Audiens</label><input style={s.input} value={pAudiens} onChange={e => setPAudiens(e.target.value)} placeholder="Wanita 20-35 tahun" /></div>
            </div>
            <div style={s.field}><label style={s.label}>Deskripsi</label><input style={s.input} value={pDeskripsi} onChange={e => setPDeskripsi(e.target.value)} placeholder="Serum vitamin C untuk kulit cerah" /></div>
            <div style={s.field}><label style={s.label}>Keunggulan</label><textarea style={s.textarea} value={pKeunggulan} onChange={e => setPKeunggulan(e.target.value)} placeholder="15% vitamin C, dermatologist tested, harga terjangkau..." /></div>
            <button style={savingProduk ? s.btnDisabled : s.btn} onClick={saveProduk} disabled={savingProduk}>
              {savingProduk ? 'Menyimpan...' : '💾 Simpan ke Google Sheets'}
            </button>

            <h3 style={{ fontSize: 15, fontWeight: 600, marginTop: 28, marginBottom: 8 }}>📋 Data Produk Tersimpan</h3>
            {loadingProduk ? <p style={{ color: '#888', fontSize: 14 }}>Memuat data...</p> : produkList.length === 0 ? <p style={{ color: '#888', fontSize: 14 }}>Belum ada data produk.</p> : (
              <div style={{ overflowX: 'auto' }}>
                <table style={s.produkTable}>
                  <thead><tr><th style={s.th}>Nama</th><th style={s.th}>Deskripsi</th><th style={s.th}>Audiens</th><th style={s.th}>Keunggulan</th></tr></thead>
                  <tbody>{produkList.map((p, i) => <tr key={i}><td style={s.td}>{p.nama}</td><td style={s.td}>{p.deskripsi}</td><td style={s.td}>{p.audiens}</td><td style={s.td}>{p.keunggulan}</td></tr>)}</tbody>
                </table>
              </div>
            )}
          </>
        )}

        {tab !== 'produk' && (
          <>
            <button style={loading ? s.btnDisabled : s.btn} onClick={generate} disabled={loading}>
              {loading ? '⏳ Sedang memproses...' : '✨ Generate'}
            </button>
            {saved && <span style={s.savedBadge}>✅ Tersimpan ke Google Sheets</span>}
            {result && <div style={s.result}>{result}</div>}
          </>
        )}
      </div>
    </div>
  );
}
