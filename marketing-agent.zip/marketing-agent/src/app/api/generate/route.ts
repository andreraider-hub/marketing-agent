import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';
import { appendToSheet, ensureSheetTabs } from '@/lib/sheets';

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const TAB_MAP: Record<string, string> = {
  ads: 'Ads',
  seo: 'SEO',
  copy: 'Copywriting',
  konten: 'Ide Konten',
  analisis: 'Analisis',
};

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { tab, prompt, meta } = body;

    const message = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1500,
      messages: [{ role: 'user', content: prompt }],
    });

    const result = message.content
      .map((b) => (b.type === 'text' ? b.text : ''))
      .join('');

    // Save to Google Sheets
    try {
      await ensureSheetTabs();
      const sheetTab = TAB_MAP[tab] || tab;
      const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      await appendToSheet(sheetTab, [now, meta || '', result]);
    } catch (sheetErr) {
      console.error('Sheet error (non-fatal):', sheetErr);
    }

    return NextResponse.json({ result });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Terjadi kesalahan' }, { status: 500 });
  }
}
