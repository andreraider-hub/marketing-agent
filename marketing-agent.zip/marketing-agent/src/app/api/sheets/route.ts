import { NextRequest, NextResponse } from 'next/server';
import { appendToSheet, readFromSheet, ensureSheetTabs } from '@/lib/sheets';

export async function GET() {
  try {
    await ensureSheetTabs();
    const rows = await readFromSheet('Produk');
    // skip header row
    const data = rows.slice(1).map((r) => ({
      nama: r[0] || '',
      deskripsi: r[1] || '',
      audiens: r[2] || '',
      keunggulan: r[3] || '',
    }));
    return NextResponse.json({ data });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Gagal membaca data' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { nama, deskripsi, audiens, keunggulan } = await req.json();
    await ensureSheetTabs();
    // ensure header
    const rows = await readFromSheet('Produk');
    if (rows.length === 0) {
      await appendToSheet('Produk', ['Nama Produk', 'Deskripsi', 'Target Audiens', 'Keunggulan']);
    }
    await appendToSheet('Produk', [nama, deskripsi, audiens, keunggulan]);
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: 'Gagal menyimpan' }, { status: 500 });
  }
}
